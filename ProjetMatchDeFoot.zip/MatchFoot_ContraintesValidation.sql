describe Joueurs;
describe Actions;
describe Equipes;
describe Matchs;

-- un match doit durer 90min 

alter table Actions 
add constraint duree_match check (Minute_Action < 90); 

  

-- les numéro de maillot doivent être positif et inférieur à 100 

alter table Joueurs 
add constraint num_maillot_max check (Numéro_maillot < 100 ); 

alter table Joueurs
add constraint num_maillot_min check (Numéro_maillot >= 0 ); 

  

-- l'âge d'un joueur doit être compris entre 15 et 100

alter table Joueurs 
add constraint age_min check ( date_naissance <= '2009-01-01'); 


alter table Joueurs
add constraint age_max check ( date_naissance >= '1924-01-01'); 

  

-- Le poids doit être compris entre 40 et 110 

alter table Joueurs 

add constraint poids_Max check ( Poids < 110); 

alter table Joueurs
add constraint poids_Min check ( Poids > 40 ); 

  

-- la date de déroulement des matchs doit correspondre à la saison actuelle

alter table Matchs 
add constraint date_min check ( Date_Déroulement >= '2024-08-01'); 

alter table Matchs
add constraint date_max check ( Date_Déroulement <= '2025-05-25'); 