-- Affiche le nom et prenom des joueurs Jouant à Paris
SELECT Nom, Prenom FROM Joueurs WHERE Club='Paris';

-- Affiche le nom et prénom des joueurs pesant plus de 70 kg
SELECT Nom, Prenom from Joueurs WHERE Poids>=70;

-- Affiche le nom et prénom des joueurs qui jouue Attaquant
SELECT Nom, Prenom FROM Joueurs WHERE Poste = 'Attaquant';

-- Affiche le nom et prénom des joueurs dont le numéro de maillot est inférieur ou égal à 10
SELECT Nom, Prenom FROM Joueurs WHERE Numero_Maillot <= 10;


-- Affiche le Nom du club et de son entraineur par ordre alphabétique des noms de club
SELECT Nom_Club, Nom_Entraineur FROM equipes ORDER BY Nom_Club;


-- Affiche le Nom des clubs uilisant le dispositif 4-4-2
SELECT Nom_Club FROM equipes WHERE Dispositif = '4-4-2';

-- Affiche le nom des Equipes accueillies par Paris
SELECT Equipe_Exterieur FROM matchs WHERE Equipe_Domicile = 'Paris';


